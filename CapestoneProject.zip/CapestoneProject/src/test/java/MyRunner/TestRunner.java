package MyRunner;

import org.junit.runner.RunWith;

import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;

@RunWith(Cucumber.class) //specifies the test runner that it should run Cucumber tests 
@CucumberOptions(
		features="C:\\Users\\soniy\\Desktop\\ITLearnFramework\\src\\test\\java\\feature\\login.feature",
		glue= {"stepDef", "com.itlearn.hooks"},
		plugin= {"pretty",
				"html:cReports/cucumberReport.html",
				"json:cReports/cucumberReport.json",
				"junit:cReports/cucmberReport.xml"
				
		}
		
		//tags="@Valid"
		//publish=true
)


public class TestRunner {
	
}