package com.itlearn.testcases;

import org.testng.annotations.Test;

import com.itlearn.pages.BaseTest;
import com.itlearn.pages.TitlePage;


public class TitleTest extends BaseTest {
	
	@Test(priority =1)
	void TitleCheck() {
		
		TitlePage tp = new TitlePage(driver);
		tp.validateTitle();
	}
}
