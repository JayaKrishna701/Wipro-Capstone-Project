package com.itlearn.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.FindBy;



public class CheckBoxPage extends BaseTest {
	
	WebDriver driver;
	//constructor
	public CheckBoxPage(WebDriver lDriver)
	{
		this.driver=lDriver;
		
		PageFactory.initElements(driver,this);
	}
	
	@FindBy(xpath = "//*[@id=\"menu-item-13318\"]/a/span") WebElement freeCourses;
	
	@FindBy(xpath = "//label[@for=\"aca_9247\"]") WebElement chBox1;

	
	public void validatecheckBox() {
		
		freeCourses.click();
		
		System.out.println(chBox1.isSelected()); //false
		
		//Action
		chBox1.click();
		System.out.println(chBox1.isDisplayed()); //true
		System.out.println(chBox1.isEnabled()); //true
		System.out.println(chBox1.isSelected());//true
		
	}

}
