package com.itlearn.testcases;
import org.testng.annotations.Test;
import com.itlearn.pages.BaseTest;
import com.itlearn.pages.LogoPage;


public class LogoTest extends BaseTest{
	
	@Test(priority =1)
	void LogoCheck() {
		
		LogoPage lp = new LogoPage(driver);
		lp.validateLogo();
		//driver.close();
	}
}