package com.itlearn.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class LogoPage extends BaseTest{
	
	WebDriver driver;
	//constructor
	public LogoPage(WebDriver lDriver)
	{
		this.driver=lDriver;
		
		PageFactory.initElements(driver,this);
	}
	
	@FindBy(xpath="//*[@id=\"logo\"]/a/span") WebElement logo;
	
	public void validateLogo() {
		
		logo.click();
		System.out.println("Logo is validated");
	}
}