package com.itlearn.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

public class TitlePage extends BaseTest {
	
	WebDriver driver;
	//constructor
	public TitlePage(WebDriver lDriver)
	{
		this.driver=lDriver;
		
		PageFactory.initElements(driver,this);
	}
	
	public void validateTitle() {
		String title = driver.getTitle();
		System.out.println("Page Title: "+title);
		Assert.assertEquals("Online Training – Courses & Certification | ITLearn360", title);
		System.out.println("Title is matching");
		
	}

}
