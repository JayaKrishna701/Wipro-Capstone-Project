package com.itlearn.testcases;

import org.testng.annotations.Test;

import com.itlearn.pages.BaseTest;
import com.itlearn.pages.CheckBoxPage;


public class CheckBoxTest extends BaseTest {
	
	@Test(priority =1)
	void CheckBoxCheck() {
		
		CheckBoxPage cp = new CheckBoxPage(driver);
		cp.validatecheckBox();
		
	}
}
